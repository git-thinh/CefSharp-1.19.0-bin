﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CefSharp.WinForms.Example")]
[assembly: AssemblyCompany("Anthony Taranto")]
[assembly: AssemblyProduct("CefSharp")]
[assembly: AssemblyCopyright("Copyright © Anthony Taranto 2012")]

[assembly: AssemblyVersion("1.19.0.*")]
[assembly: ComVisible(false)]
